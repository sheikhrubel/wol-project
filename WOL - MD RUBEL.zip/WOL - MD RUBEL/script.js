const insert = (num) => {
    if(document.form.textview.value === 0){
        clean()
    }
    document.form.textview.value = document.form.textview.value+num
}
const equal = () => {
    document.form.textview.value = eval(document.form.textview.value)
}
const clean = () => {
    document.form.textview.value = "";
}
const alert = () => {
    window.alert("Thank you so much for visiting us")
}

